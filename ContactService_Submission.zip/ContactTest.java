package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreatedSuccessfully() {
        Contact contact = new Contact("1234567890", "Sara", "Stovall", "8155551234", "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("Sara", contact.getFirstName());
        assertEquals("Stovall", contact.getLastName());
        assertEquals("8155551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Sara", "Stovall", "8155551234", "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Sara", "Stovall", "8155551234", "123 Main");
        });
    }

    @Test
    public void testFirstNameCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Stovall", "8155551234", "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "LongFirstName", "Stovall", "8155551234", "123 Main");
        });
    }

    @Test
    public void testLastNameCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", null, "8155551234", "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "LongLastName", "8155551234", "123 Main");
        });
    }

    @Test
    public void testPhoneMustBeTenDigitsAndNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", null, "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", "815555123", "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", "81555512345", "123 Main");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", "815ABC1234", "123 Main");
        });
    }

    @Test
    public void testAddressCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", "8155551234", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Sara", "Stovall", "8155551234", "1234567890123456789012345678901");
        });
    }

    @Test
    public void testSettersWorkCorrectly() {
        Contact contact = new Contact("1", "Sara", "Stovall", "8155551234", "123 Main");

        contact.setFirstName("Sam");
        contact.setLastName("Smith");
        contact.setPhone("7085559999");
        contact.setAddress("456 Oak");

        assertEquals("Sam", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("7085559999", contact.getPhone());
        assertEquals("456 Oak", contact.getAddress());
    }
}