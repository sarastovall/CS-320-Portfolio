package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "Sara", "Stovall", "8155551234", "123 Main");

        service.addContact(contact);

        assertEquals("Sara", service.getContact("1").getFirstName());
    }

    @Test
    public void testCannotAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "Sara", "Stovall", "8155551234", "123 Main");
        Contact duplicate = new Contact("1", "John", "Smith", "7085559999", "456 Oak");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(duplicate);
        });
    }

    @Test
    public void testCannotAddNullContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    @Test
    public void testDeleteContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "Sara", "Stovall", "8155551234", "123 Main");

        service.addContact(contact);
        service.deleteContact("1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("1");
        });
    }

    @Test
    public void testDeleteMissingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("missing");
        });
    }

    @Test
    public void testUpdateContactFieldsSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "Sara", "Stovall", "8155551234", "123 Main");

        service.addContact(contact);
        service.updateFirstName("1", "Sam");
        service.updateLastName("1", "Smith");
        service.updatePhone("1", "7085559999");
        service.updateAddress("1", "456 Oak");

        assertEquals("Sam", service.getContact("1").getFirstName());
        assertEquals("Smith", service.getContact("1").getLastName());
        assertEquals("7085559999", service.getContact("1").getPhone());
        assertEquals("456 Oak", service.getContact("1").getAddress());
    }
}